app.controller('usersController', ['$scope', '$location', 'usersFactory', function ($scope, $location, usersFactory) {

	$scope.user = {};
	$scope.errors = {};

	$scope.userReg = function() {
		console.log($scope.newUser);
		usersFactory.create($scope.newUser, function(data){
			if (data.message === "User validation failed") {
					$scope.errors = data;
					$location.url('/')
					console.log($scope.errors);
			}
			$scope.user = data;
		})
		$location.url('/success')
	}

	$scope.loginReg = function() {
		console.log($scope.possibleUser);
		usersFactory.login($scope.possibleUser, function(data){
			if (data.name === "Validation error") {
				$scope.errors = data;
				$location.url('/')
				console.log($scope.errors);
			}
			$scope.user = data;
			console.log($scope.user);
		})
		$location.url('/success')
	}

	$scope.logout = function() {
		$scope.user = {};
		console.log($scope.user);
		$location.url('/')
	}

}]);